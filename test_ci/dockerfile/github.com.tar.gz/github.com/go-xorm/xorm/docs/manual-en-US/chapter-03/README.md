## 3. database meta information

xorm provides methods to getting and setting table schema. For less schema changing production, `engine.Sync()` is enough.