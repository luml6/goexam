# Package information

Ignore this `low-level access `package's source code and use the Iris' websocket `high level access library` instead.

# Docs

- Book section:  https://kataras.gitbooks.io/iris/content/package-websocket.html
- Examples: https://github.com/iris-contrib/examples/tree/master/websocket , https://github.com/iris-contrib/examples/tree/master/websocket_native_messages, https://github.com/iris-contrib/examples/tree/master/websocket_unlimited_servers
