## Repository information

This package is a -light edited- clone of [formam](https://github.com/monoculum/formam).


- Docs [here](https://kataras.gitbooks.io/iris/content/request-body-bind.html)
- Examples [here](https://github.com/iris-contrib/examples)
