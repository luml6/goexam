## Middleware information

This folder contains a middleware which is a bridge between Iris station's logger and http requests.


## Install

```sh
$ go get -u github.com/iris-contrib/middleware/logger
```

**Logs the incoming requests**

## How to use

Read the logger section [here](https://kataras.gitbooks.io/iris/content/logger.html)
