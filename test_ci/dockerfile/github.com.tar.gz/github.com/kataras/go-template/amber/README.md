## Folder information

This folder contains the buit'n [amber](https://github.com/eknkc/amber) cross-framework template engine support.
