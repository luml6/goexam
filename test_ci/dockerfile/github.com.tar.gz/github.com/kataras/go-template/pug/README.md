## Folder information

This folder contains the [pug/jade](https://github.com/Joker/jade) cross-framework template engine support.
