## Folder information

This folder contains the buit'n [handlebars/raymond](https://github.com/aymerick/raymond) cross-framework template engine support.
