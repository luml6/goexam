## Folder information

This folder contains the buit'n [django/pongo2](https://github.com/flosch/pongo2) cross-framework template engine support.
