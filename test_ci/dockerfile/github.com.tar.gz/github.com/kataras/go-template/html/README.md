## Folder information

This folder contains the buit'n and the default [html/template](https://golang.org/pkg/text/template) cross-framework template engine support.
