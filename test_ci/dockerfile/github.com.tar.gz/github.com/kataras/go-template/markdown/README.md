## Folder information

This folder contains the [markdown/blackfriday](https://github.com/russross/blackfriday) cross-framework template engine support.
