package data

// Config is the configuration for the serializer, it's empty
type Config struct{}
