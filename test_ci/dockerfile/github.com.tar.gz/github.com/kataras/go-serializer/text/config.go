package text

// Config is the configuration for this serializer, it's empty
type Config struct{}
