// Package websocket provides an easy way to setup a rich Websocket server and client side.
package websocket

const (
	// Version current version number
	Version = "0.0.2"
)
