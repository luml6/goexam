- Version : **5.0.1**

- Operating System:

- [x] I have read the [book](https://docs.iris-go.com), [examples](https://github.com/iris-contrib/examples), [contributing file](https://github.com/kataras/iris/blob/master/.github/CONTRIBUTING.md) and **I'm sure that this issue is not posted** & answered before.

--------------
