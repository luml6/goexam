
I spend all my time in the construction of Iris, therefore I have no income value.

If you,

- think that any information you obtained here is worth some money
- believe that Iris worths to remains a highly active project

Feel free to send **any** amount through paypal

[![](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=kataras2006%40hotmail%2ecom&lc=GR&item_name=Iris%20web%20framework&item_number=iriswebframeworkdonationid2016&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted)

> Please check your e-mail after your donation

Benefits:

- Your github username, after your approval, is visible here.
- Access to the 'donors' [private chat room](https://kataras.rocket.chat/group/donors), real-time assistance by me.
- Each donate gives lifetime to the Iris web framework. The author works full-time on this project, no time for any part-time job.

**Thank you**!

### More about your donations


I'm  grateful for all the generous donations. Iris is fully funded by these donations.

#### Donations

- ASKED FOR ANONYMITY* donated 50 EUR at May 11

- [Juan Sebastián Suárez Valencia](https://github.com/Juanses) donated 20 EUR at September 11

- [Bob Lee](https://github.com/li3p) donated 20 EUR at September 16

- [Celso Luiz](https://github.com/celsosz) donated 50 EUR at September 29

- ANONYMOUS(Waiting For Approval)* donated 6 EUR at October 1

- [Ankur Srivastava](https://github.com/ansrivas) donated 20 EUR at October 2

- ANONYMOUS(BY OWN WILL)* donated 100 EUR at October 18

- ANONYMOUS(Waiting For Approval) donated 20 EUR at October 19

- [Damon Zhao](https://github.com/se77en) donated 20 EUR at October 21

- ANONYMOUS(BY OWN WILL)* donated 50 EUR at October 21

- [exponity - consulting & digital transformation](https://github.com/exponity) donated 30 EUR at November 4

> * The name or/and github username link added after donator's approvement via e-mail.

#### Report, so far

- 13 EUR for the domain, [iris-go.com](https://iris-go.com)

**Available**: VAT(50) + VAT(20) + VAT(20) + VAT(50) + VAT(6) + VAT(20) + VAT(100) + VAT(20) + VAT(20) + VAT(50) + VAT(30) - 13 = 47,45 + 18,97 + 18,61 + 47,05 + 5,34 + 18,97 + 98,04 + 18,97 + 18,61 + 47,95 + 28,24 - 13 =
354,31 EUR

> November 2016: The publication of the report is stopped. Any updated report will be delivered to the donors and only to them.
